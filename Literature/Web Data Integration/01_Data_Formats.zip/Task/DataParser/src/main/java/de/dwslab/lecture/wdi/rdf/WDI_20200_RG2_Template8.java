package de.dwslab.lecture.wdi.rdf;

import org.apache.jena.query.*;
import org.apache.jena.rdf.model.Model;
import org.apache.jena.rdf.model.ModelFactory;
import org.apache.jena.vocabulary.RDFS;

public class WDI_20200_RG2_Template8 {

    public static void main(String[] args) {
        // create RDF model

        // fill the model with the data from the file

        // the sparql query to select the names and ids of all countries
        // differentiate between the country and the language entities by keeping the entities that have a population property


        // create the query


        // execute the query

        // parse the results


    }
}
