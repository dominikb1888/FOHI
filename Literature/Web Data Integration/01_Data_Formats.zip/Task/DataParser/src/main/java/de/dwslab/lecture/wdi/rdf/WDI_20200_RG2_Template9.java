package de.dwslab.lecture.wdi.rdf;

public class WDI_20200_RG2_Template9 {

    public static void main(String[] args) {
        // create RDF model

        // fill the model with the data from the file

        // the sparql query to select the second five most populated countries


        // create the query


        // execute the query

        // parse the results


    }
}
