package de.dwslab.lecture.wdi.xml;

import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.IOException;

public class WDI_20200_RG2_Template5 {
    public static void main(String[] args) throws ParserConfigurationException,
            SAXException, IOException, XPathExpressionException {

        // create the factory

        // create a new document builder

        // parse a document


        // define an xpath expression


        // select the country nodes of countries which are in Europe and Asia




    }

}
