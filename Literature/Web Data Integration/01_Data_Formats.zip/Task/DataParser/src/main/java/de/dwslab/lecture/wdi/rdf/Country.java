package de.dwslab.lecture.wdi.rdf;

public class Country {
	String id;
	String name;
	Long population;
	String[] languages;

}
