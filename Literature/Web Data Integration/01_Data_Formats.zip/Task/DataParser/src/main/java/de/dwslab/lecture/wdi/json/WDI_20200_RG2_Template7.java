package de.dwslab.lecture.wdi.json;

import com.google.gson.Gson;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class WDI_20200_RG2_Template7 {

    public static void main(String[] args) throws ParserConfigurationException,
            SAXException, IOException, XPathExpressionException {

        // creat gson object

        // create a reader

        // initalize total count of population

        // iterate through the file - line by line

            // read the line

            // convert it to a country object

            // sum the population


        // close the reader

        // print result


    }
}
