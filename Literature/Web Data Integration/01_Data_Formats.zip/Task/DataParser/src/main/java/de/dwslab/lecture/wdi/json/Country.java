package de.dwslab.lecture.wdi.json;

public class Country {
	String id;
	String name;
	String car_code;
	Long population;
}