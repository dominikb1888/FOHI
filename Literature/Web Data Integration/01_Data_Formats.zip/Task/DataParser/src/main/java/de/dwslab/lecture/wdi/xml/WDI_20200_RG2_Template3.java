package de.dwslab.lecture.wdi.xml;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.IOException;

public class WDI_20200_RG2_Template3 {
    public static void main(String[] args) throws ParserConfigurationException,
            SAXException, IOException, XPathExpressionException {

        // create the factory

        // create a new document builder

        // parse a document


        // define an xpath expression


        // select the countries, who are encompassed in a continent which has the name Europe





    }

}
