package de.dwslab.lecture.wdi.xml;

import com.google.gson.Gson;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class WDI_20200_RG2_Template1 {
    public static void main(String[] args) throws ParserConfigurationException,
            SAXException, IOException, XPathExpressionException {

        // create the factory

        // create a new document builder

        // parse a document -- make sure the file is located on root level


        // define an xpath expression


        // select the root node

        // parse the node

        // print the node name



    }

}
